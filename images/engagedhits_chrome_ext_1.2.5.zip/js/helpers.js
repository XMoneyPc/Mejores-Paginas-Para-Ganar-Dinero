async function getAutomaticModeVideosCount(){
    let count =  (await store.get('automaticModeVideosCount')).automaticModeVideosCount;
    if (typeof count == 'undefined') {
        let response = null;
        try {
            response = await api.get('task/getAutoCompletedTasksCount');
        } catch (e) {
            log('error', e)
        }
        if (response && response.type == 'success') {
            count = response.tasksCount;
        } else {
            count = 0;
        }
        await store.set('automaticModeVideosCount', count || 0);
    }
    return count;
}

async function wipeAutomaticModeVideosCount() {
    await store.set('automaticModeVideosCount', 0);
}

async function incrementWatchedTestVideos(){
    let automaticModeVideosCount = await getAutomaticModeVideosCount();
    let limit = await getAutomaticModeLimit();
    automaticModeVideosCount++;
    if (automaticModeVideosCount >= limit) {
        automaticModeVideosCount = 0;
    }
    await store.set('automaticModeVideosCount', automaticModeVideosCount);
    return automaticModeVideosCount;
}

async function disableAutomacticMode(){
    let autoWatchingTabId = (await store.get('autoWatchingTabId')).autoWatchingTabId;                
    if(autoWatchingTabId){
        chrome.tabs.remove(autoWatchingTabId);
        await stopAutomaticMode();
    }
    await store.set('disableAutomaticMode', true);
    await store.remove(['nextEarnType']);
}

async function stopAutomaticMode(){
    await store.remove("autoWatchingTabId");
}

async function isAutomaticModeActive(){
    let autoWatchingTabId = (await store.get('autoWatchingTabId')).autoWatchingTabId;
    if(autoWatchingTabId){
        return true;
    }              
    return false;
}

async function getAutomaticModeTimeout(){
    let settings    = await settingsModel.get();
    let amTimeout   = 30;

    try{
        if(settings.amTimeout){
            amTimeout = parseInt(settings.amTimeout);
        }
    }catch(e){
        log(e);
    }
    return amTimeout;
}

async function getAutomaticModeLimit(){
    let settings        = await settingsModel.get();
    let amVideosLimit   = 10;

    try{
        if(settings.amVideosLimit){
            amVideosLimit = parseInt(settings.amVideosLimit);
        }
    }catch(e){
        log(e);
    }
    return amVideosLimit;
}

async function userAndIpCanContinueAfter(){
    try{
        return await api.get('task/userAndIpCanContinueAfter');
    }
    catch(e){
        log(e);
    }
    return null;
}

async function isAutomaticModeEnabled(){
    if((await store.get('disableAutomaticMode')).disableAutomaticMode){
        return false;
    }
    return true;
}

async function nextAvailableTaskAfter(){
    try{
        let response = await api.get('task/nextAvailableTaskAfter');
        if(response.after){
            return response.after;
        }
    }
    catch(e){
        log(e);
    }
    return null;
}

async function getNextTask(){
    let user = await userModel.get().catch(exception => { });
    let nextEarnType = (await store.get('nextEarnType').catch(exception => { })).nextEarnType;

    if(!nextEarnType){
        nextEarnType = "points";
    }

    if(nextEarnType == "points" || (nextEarnType == "money" && user && user.canEarnMoney == '1')){
        try{
            await taskModel.get(true, nextEarnType);
        }
        catch(exception){
            if(exception.error == 'ERR_NO_TASK') {
                await store.remove("autoWatchingTabId");
            }
        }
    }

}

async function skipTask(reason = "videoNotFound", explanation = ""){
    let result = await new Promise(async(resolve) => {
        chrome.runtime.sendMessage({
            action: 'markTaskCancelled',
            reason: reason,
            explanation: explanation
        }, response => resolve(response));
    });

    if(result.isSuccessful){
        await executeFromBackground('getNextTask');
    }
}

async function executeFromBackground(functionName, args){
    if(location.protocol === 'chrome-extension:'){
        return await window[functionName].apply(null, args);
    }
    else{
        return await new Promise((resolve) => {
            chrome.runtime.sendMessage({ action: 'executeFromBackground', functionName: functionName, args: args}, function(response){
                resolve(response);
            });
        });
    }
}