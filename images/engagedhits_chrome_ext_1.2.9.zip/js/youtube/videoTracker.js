const videoTracker = (function(){
    let isInit = false;
    let video = null;
    let seekAlerted = false;
    let seekAlertVisible = false;
    let taskVideoId = null;
    let likedStatus = null;
    let dislikedStatus = null;
    let subscribedStatus = null;
    let lsInterval = null;
    let pingInterval = null;
    let statusUIHtml = `
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
        <div class="eh-task-status">
            <div class="eh-task-header">
                <img src="{{logoPath}}" />
            </div>
            <div class="eh-task-list"></div>
        </div>
    `;
    let prevCurrentTime = null;
    let currentTask = null;
    let updatePingInterval = 5; // default update ping interval in minute
    let settings;
    let skipAttemptByKbTime = null;
    let skipAttemptByMouseTime = null;
    let skipAttemptVidTime = null;
    let vidResumeTime = false;
    let maxPlayBackRate = 1;

    let subscriptionScheduled = false;
    let likeScheduled = false;
    let commentScheduled = false;
    let videoLoadedChecker = null;
    let watchingStart = null;

    // list of tasks which this tracker can handle
    let tasks = {
        watchVideo: {
            required: false,
            isCompleted: false,
            text: getLocaleMsg('ytTask_watchVideo'),
            seconds: 0
        },
        likeVideo: {
            required: false,
            isCompleted: false,
            text: getLocaleMsg('ytTask_likeVideo')
        },
        dislikeVideo: {
            required: false,
            isCompleted: false,
            text: getLocaleMsg('ytTask_dislikeVideo')
        },
        subscribeChannel: {
            required: false,
            isCompleted: false,
            text: getLocaleMsg('ytTask_subscribeChannel')
        },
        postComment: {
            required: false,
            isCompleted: false,
            text: getLocaleMsg('ytTask_postComment'),
            comment: 'great video'
        }
    };

    let getStatusUIHtml = () => {
        let logoPath = chrome.runtime.getURL('/images/logos/engagedhits.png');

        let tasksHtml = $('<div/>').addClass('eh-tasks-wrap');

        for(let taskIndex in tasks) {
            let task = tasks[taskIndex];

            if(!task.required) {
                continue;
            }

            let taskText = task.text;
            let extraHtml = '';
            if(taskIndex == 'watchVideo') {
                extraHtml += `
                    <div class="eh-task-info eh-time-left">` + getLocaleMsg('timeLeft') + `: <span></span></div>
                `;

                let hours = Math.floor(task.watchDuration / 3600);
                let minutes = Math.floor(task.watchDuration % 3600 / 60);
                let seconds = Math.floor(task.watchDuration % 3600 % 60);
                taskText = getLocaleMsg('ytTask_watchVideo',[
                    hours ? getLocaleMsg('hours', hours.toString()) : '',
                    minutes ? getLocaleMsg('minutes', minutes.toString()) : '',
                    seconds ? getLocaleMsg('seconds', seconds.toString()) : ''
                ]);
            }
            else if(taskIndex == 'postComment') {
                extraHtml += `
                <div class="eh-task-info">
                    <div id="postCommentInfo">
                        <input type="text" id="ehTaskComment" value="` + task.comment + `" readonly>
                        <button class="btn btn-primary btn-sm btn-copy" data-copy-ele="ehTaskComment" type="button">` + getLocaleMsg('copy') + `</button>
                    </div>
                </div>
                `;
            }

            let faClass = task.isCompleted ? 'fa-check-circle' : 'fa-circle';
            tasksHtml.append(`
                <div class="eh-task ` + (task.isCompleted ? 'eh-task-completed' : '') + ` ehTask-` + taskIndex + `">
                    <div class="eh-task-status-icon"><i class="fa ` + faClass + `"></i></div>
                    <div class="eh-task-text">` + taskText + `</div>
                    ` + extraHtml + `
                </div>
            `);
        }

        statusUIHtml = statusUIHtml.replace('{{logoPath}}', logoPath);
        let tempDiv = $('<div/>').append(statusUIHtml)
        tempDiv.find('.eh-task-list').append(tasksHtml);

        return tempDiv.html();
    };

    // create UI of tasks status in primary column of youtube video watching page
    let createPrimaryColTaskStatusUI = () => {

        if($('#primary.ytd-watch-flexy .eh-task-status').length && $('#primary.ytd-watch-flexy #related.ytd-watch-flexy').length == 0) {
            $('#primary.ytd-watch-flexy .eh-task-status').hide();
            return;
        }

        if($('#primary.ytd-watch-flexy .eh-task-status').length || $('#primary.ytd-watch-flexy #related.ytd-watch-flexy').length == 0) {
            $('#primary.ytd-watch-flexy .eh-task-status').length && $('#primary.ytd-watch-flexy .eh-task-status').show();
            return;
        }

        $('#primary.ytd-watch-flexy #related.ytd-watch-flexy').before(getStatusUIHtml());

        log('primary column task status UI created');
    };

    // create UI of tasks status in secondary column of youtube video watching page
    let createSecondaryColTaskStatusUI = () => {
        if($('#secondary.ytd-watch-flexy .eh-task-status').length) {
            return;
        }

        $('#secondary.ytd-watch-flexy').prepend(getStatusUIHtml());

        log('secondary column task status UI created');
    };

    // to remove task status UI
    let removeTaskStatusUI = () => {
        $('#secondary.ytd-watch-flexy .eh-task-status').remove();
        log('task status UI removed');
    };

    // common utility function to mark task as completed by taskId provided
    let markTaskComplete = async (taskId) => {
        if(taskId == 'watchVideo' && video) {
            video.pause();
        }

        tasks[taskId].isCompleted = true;
        $('.ehTask-' + taskId).addClass('eh-task-completed');
        $('.ehTask-' + taskId).find('.eh-task-status-icon i').addClass('fa-check-circle').removeClass('fa-circle');
        log('task marked complete', taskId);

        // check if all tasks completed
        let isAllCompleted = true;
        for(let taskId in tasks) {
            if(tasks[taskId].required == false) {
                continue;
            }
            if(tasks[taskId].isCompleted == false) {
                isAllCompleted = false;
                break;
            }
        }

        let autoWatchingTaskCompleteHandler = async () => {
            await executeFromBackground('incrementWatchedTestVideos');
            const response = await executeFromBackground('userAndIpCanContinueAfter');
            if (response && response.userCanContinueAfter === 0 && response.ipCanContinueAfter === 0){
                await executeFromBackground('getNextTask');
                window.location.href = "https://www.youtube.com/";
            }
            else {
                const tab = await store.get("autoWatchingTabId");
                await stopAutomaticMode();
                ehPopup.alert(getLocaleMsg('msgAutomaticModeEnd', [(await executeFromBackground('getAutomaticModeTimeout'))]));
                chrome.runtime.sendMessage({
                    action: 'continueWhenTimeoutGone',
                    timeout: await getAutomaticModeTimeout() * 60 * 1000,
                    tabId: tab.autoWatchingTabId,
                });
            }
        };

        if (isAllCompleted) {
            // if((+ new Date() - watchingStart) / 1000 < tasks.watchVideo.watchDuration){
            //     await executeFromBackground('reportCheater');
            //     ehPopup.alert(getLocaleMsg('speedUpAlert'), async () => {
            //         window.location = "https://youtube.com";
            //     }, true, "I understand and have removed the speeding up extension");
            // }
            // else{
                chrome.runtime.sendMessage({ action: 'markTaskComplete', automation: isTabAutoWatching }, response => {
                    if (response.isSuccessful) {
                        if(isTabAutoWatching){
                            autoWatchingTaskCompleteHandler();
                        }
                        else{
                            if (currentTask.earnType == 'money' && typeof currentTask.earnMoneyOffer != 'undefined' && (currentTask.earnMoneyOffer.watched_videos + 1) == currentTask.earnMoneyOffer.total_videos) {
                                store.remove('nextEarnType');
                                ehPopup.alert(getLocaleMsg('ytVideoEmConvCompleted'));
                            }
                            else if(currentTask.visitType == 'search') {
                                ehPopup.alert(getLocaleMsg('ytVideoSearchTaskCompleted'));
                            }
                            else {
                                ehPopup.alert(getLocaleMsg('ytVideoTaskCompleted'));
                            }
                        }
                        clear();
                    }
                    else if(response.data && typeof response.data.error != 'undefined' && response.data.error == 'unauthorized') {
                        ehPopup.alert(getLocaleMsg('msgUnauthorized'));
                        clear();
                    }
                    else {
                        ehPopup.alert(getLocaleMsg('msgFailedToMarkTaskComplete'));
                    }
                });
            // }
        }

        if(!isAllCompleted && taskId == 'watchVideo') {
            chrome.runtime.sendMessage({action: 'setVideoWatchedBadge'});
        }
    };

    // common function to mark task as incoplete provided taskId
    let markTaskIncomplete = (taskId) => {
        tasks[taskId].isCompleted = false;
        $('.ehTask-' + taskId).removeClass('eh-task-completed');
        $('.ehTask-' + taskId).find('.eh-task-status-icon i').removeClass('fa-check-circle').addClass('fa-circle');
        log('task marked incomplete', taskId);
    }

    // simple common function to handle messages received via chrome runtime
    let onMessageListener = (msg, sender, callback) => {
        if(!video) return;

        switch(msg['action']) {

            // received from background.js when first email date found
            case 'commentPosted':
                log('comment posted', {
                    commentPosted: msg['comment'],
                    taskComment: tasks.postComment.comment
                });

                if($.trim(msg['comment']) == $.trim(tasks.postComment.comment)) {
                    markTaskComplete('postComment');
                    checkCommentStatus();
                }
                else {
                    ehPopup.alert(getLocaleMsg('ytVideoIncorrectCommentPosted'));
                }
                break;
        }

        return true;
    };

    // To update remaining time of watching video and mark task complete
    let videoTimeUpdateListner = () => {
        if(tasks.watchVideo.isCompleted) {
            log('ignored timeupdate as watch video task is completed');
            return;
        }

        if(seekAlertVisible) {
            log('ignored timeupdate as seek alert is visible');
            return;
        }

        // only mouse event skip to consider. 
        // right arrow press skip can get tricky when user might not have actually tried to skip such as while typing in search box or comment box
        if(skipAttemptByMouseTime) {
            setTimeout(videoTimeUpdateListner, 1000);
            log('delayed timeupdate by a second as seek has been detected', {
                skipAttemptByMouseTime: skipAttemptByMouseTime,
                skipAttemptByKbTime: skipAttemptByKbTime
            });
            return;
        }

        let currentTime = video.currentTime;

        // check if it is ad video playing
        if($('video:first').parents('.html5-video-player').hasClass('ad-showing')) {
            if(isTabAutoWatching){
                $("button.ytp-ad-skip-button.ytp-button").simulate("click");
            }
            else{
                showSkipAdHighlight();
            }
            return;
        }

        hideSkipAdHighlight();

        //log('timeupdate', {prevCurrentTime: prevCurrentTime, currentTime: currentTime});

        // check if yt going to resume video
        if((prevCurrentTime === null && currentTime > 1) || (prevCurrentTime === 0 && vidResumeTime && currentTime == vidResumeTime)) {
            log('resume play detected. starting from 0', {
                currentTime: currentTime,
                prevCurrentTime: null
            });
            video.currentTime = 0;
            prevCurrentTime = 0;
            vidResumeTime = false;
            return;
        }

        if(currentTime > 0) {
            prevCurrentTime = currentTime;
        }

        if(!tasks.watchVideo.isCompleted && (currentTime >= tasks.watchVideo.watchDuration || currentTime >= (video.duration-1))) {
            markTaskComplete('watchVideo');
        }
        else {

            let remaining = tasks.watchVideo.watchDuration - Math.ceil(currentTime);
            if(remaining <= 5) {
                $('.ehTask-watchVideo .eh-task-info').addClass('few-sec-left');
            }
            else {
                $('.ehTask-watchVideo .eh-task-info').removeClass('few-sec-left');
            }

            if(remaining > 0) {
                let remainingTimeStr = '';
                let hours = Math.floor(remaining / 3600);
                if(hours != 0) {
                    remainingTimeStr += ('0' + hours).slice(-2) + ':';
                }
                remainingTimeStr += ('0' + Math.floor(remaining % 3600 / 60)).slice(-2) + ':';
                remainingTimeStr += ('0' + Math.floor(remaining % 3600 % 60)).slice(-2);
                $('.ehTask-watchVideo .eh-task-info span').text(remainingTimeStr);
            }
            else {
                $('.ehTask-watchVideo .eh-task-info span').text('00:00');
            }
        }
    };

    // In case user tries to skip video, alert him and restart play
    let videoSeekingListner = () => {
        if(!video) {
            return;
        }

        let currentTime = video.currentTime;

        log('video seek detected', {
            seekAlerted: seekAlerted,
            prevCurrentTime: prevCurrentTime,
            currentTime: currentTime,
            skipAttemptByKbTime: skipAttemptByKbTime,
            skipAttemptByMouseTime: skipAttemptByMouseTime,
            skipAttemptVidTime: skipAttemptVidTime
        });

        if(seekAlerted) {
            seekAlerted = false;
        }

        if(seekAlertVisible) {
            log('seek ignored as seek alert is visible');
            return;
        }

        // don't process if use has NOT attempted to skip video by keyboard arrow keys or by clicking on progress bar
        if(skipAttemptByKbTime === null && skipAttemptByMouseTime === null) {
            log('seek ignored as no skip attempt detected', {
                currentTime: currentTime
            });
            return;
        }

        // if video is already watched don't do anything
        if(tasks['watchVideo'].isCompleted) {
            log('seek ignored as video watch task is already completed', {
                currentTime: currentTime
            });
            return;
        }

        // in some rare case seek event is received 2 times, so need to detect that and ignore if user already alerted
        if(seekAlerted) {
            log('seek ignored as it has been already alerted', {
                currentTime: currentTime
            });
            return;
        }

        // ignore seek if user is seeking in past, we don't care
        if(prevCurrentTime !== null && currentTime <= prevCurrentTime) {
            // reset skip vars
            skipAttemptByKbTime = null;
            skipAttemptByMouseTime = null;
            skipAttemptVidTime = null;

            log('seek ignored as currentTime is less than prevCurrentTime', {
                currentTime: currentTime,
                prevCurrentTime: prevCurrentTime
            });
            return;
        }

        // if all above passes, then first pause the video
        video && video.pause();

        // also incomplete task the task to make sure user watches whole asked duration
        markTaskIncomplete('watchVideo');

        // alert user that they cannot skip video
        let alertMsg = '<i class="fa fa-exclamation-triangle"></i>&nbsp;&nbsp;' + getLocaleMsg('ytVidSeekedAlert');
        ehPopup.alert(alertMsg, () => {
            seekAlertVisible = false;
            seekAlerted = true;
            if(video) {

                // resume from last recorded play time
                let timeToSet = skipAttemptVidTime === null ? 0 : skipAttemptVidTime;
                prevCurrentTime = timeToSet;
                video.currentTime = timeToSet;
                video.play();
                log('video played after seek', {
                    newCurrentTime: timeToSet
                });

                // also incomplete task the task to make sure user watches whole asked duration
                markTaskIncomplete('watchVideo');

                // reset skip vars
                skipAttemptByKbTime = null;
                skipAttemptByMouseTime = null;
                skipAttemptVidTime = null;
            }
        });
        seekAlertVisible = true;
    };

    // To mark video wathching task complete in case video ended. 
    // helpful when video duration is shorter than required
    let videoPlayEndedListner = () => {
        log('video play ended');
        if($('video:first').parents('.html5-video-player').hasClass('ad-showing')) {
            log('ad video play ended');
            return false;
        }

        markTaskComplete('watchVideo');
    };

    // to detect if user changed video
    let videoMetaDataLoadedListner = () => {

        // reset skip vars
        skipAttemptByKbTime = null;
        skipAttemptByMouseTime = null;
        skipAttemptVidTime = null;

        log('video meta data loaded');
        if($('video:first').parents('.html5-video-player').hasClass('ad-showing')) {
            return;
        }

        let videoId = getParameterByName('v');
        if(videoId && video && videoId != taskVideoId) {
            log('video changed');
            ehPopup.alert(getLocaleMsg('ytVidChangedAlert'));
            clear();
        }
    };

    /**
     * Detects and stores time of right arrow key down to handle video skip
     * @param  object   event   JS object containing event info
     * @return void
     */
    let docKeydownListener = event => {
        // 39 is keycode of right arrow key
        if(event.keyCode !== 39) {
            return;
        }

        log('right arrow press detected');

        if($('video:first').parents('.html5-video-player').hasClass('ad-showing')) {
            log('ignored right arrow press as AD is playing');
            return;
        }

        if(skipAttemptVidTime === null) {
            skipAttemptVidTime = video.currentTime < prevCurrentTime ? video.currentTime : prevCurrentTime;
        }
        skipAttemptByKbTime = new Date().getTime();
    };

    /**
     * Detects and stores time of mouse click down on progress bar to handle video skip
     * @return void
     */
    let progressMousedownListener = () => {
        log('mousedown detected on progress bar');

        if($('video:first').parents('.html5-video-player').hasClass('ad-showing')) {
            log('ignored mousedown as AD is playing');
            return;
        }

        if(skipAttemptVidTime === null) {
            skipAttemptVidTime = video.currentTime < prevCurrentTime ? video.currentTime : prevCurrentTime;
        }
        skipAttemptByMouseTime = new Date().getTime();
    };

    /**
     * To detect change in playbackrate and reset it to 1x if required
     * @return {[type]} [description]
     */
    let onPlayBackRateChangeListener = () => {
        if(video && video.playbackRate > maxPlayBackRate) {
            log('playbackRate reset', video.playbackRate);
            video.playbackRate = 1;
        }
    };

    // simple utility function to create event listeners
    let createEventListeners = () => {
        
        chrome.runtime.onMessage.addListener(onMessageListener);

        // keep listening to video play progress and mark video watching task complete according to requirement
        video.addEventListener('timeupdate', videoTimeUpdateListner);

        // restart video watching if user tries to skip video
        video.addEventListener('seeking', videoSeekingListner);

        //video.addEventListener('ended', videoPlayEndedListner);

        video.addEventListener('loadedmetadata', videoMetaDataLoadedListner);

        // to disallow higher speed watch in case user tries to do so
        video.addEventListener('ratechange', onPlayBackRateChangeListener);

        // in case youtube dynamically modifies whole secondary DOM div, we need to create our UI again
        $('body').on('DOMSubtreeModified', '#secondary.ytd-watch-flexy', createSecondaryColTaskStatusUI);
        $('body').on('DOMNodeInserted', '#primary.ytd-watch-flexy', createPrimaryColTaskStatusUI);

        $(document).on('click', '.eh-task-status .btn-copy', copyInputText);
        $(document).on('keydown', docKeydownListener);
        $(document).on('mousedown', 'ytd-player .ytp-progress-bar', progressMousedownListener);

        log('event listeners created');
    };

    // to remove all event listeners created
    let removeEventListeners = () => {
        if(video) {
            video.removeEventListener('timeupdate', videoTimeUpdateListner);
            video.removeEventListener('seeking', videoSeekingListner);
            //video.removeEventListener('ended', videoPlayEndedListner);
            video.removeEventListener('loadedmetadata', videoMetaDataLoadedListner);
            video.removeEventListener('ratechange', onPlayBackRateChangeListener);
        }

        $('body').off('DOMSubtreeModified', '#secondary.ytd-watch-flexy', createSecondaryColTaskStatusUI);
        $('body').off('DOMNodeInserted', '#primary.ytd-watch-flexy', createPrimaryColTaskStatusUI);

        $(document).off('click', '.eh-task-status .btn-copy', copyInputText);
        $(document).off('keydown', docKeydownListener);
        $(document).off('mousedown', 'ytd-player .ytp-progress-bar', progressMousedownListener);

        log('event listeners removed');
    };

    let onplayListener = (task) => {
        watchingStart = + new Date();

        createEventListeners();
        createSecondaryColTaskStatusUI();
        createPrimaryColTaskStatusUI();

        // send ping every per set interval
        let tempUpdatePingInterval = parseFloat(typeof settings.updatePingInterval != 'undefined' ? settings.updatePingInterval : updatePingInterval);
        pingInterval = setInterval(() => {
            chrome.runtime.sendMessage({action: 'sendTaskInProgressPing', taskId: currentTask.taskId});
        }, 1000 * 60 * tempUpdatePingInterval);
        log('update ping interval ', tempUpdatePingInterval);

        setTimeout(async function() {
            checkIsPremiere();
            checkIsDeletedVideo();
            // if (task.mustAlreadyBeSubscribed && await checkUserUnsubscribed()) {
            //     video && video.pause();
            // }
            if(tasks['likeVideo'].required || tasks['dislikeVideo'].required || tasks['subscribeChannel'].required || tasks['postComment'].required) {
                lsInterval = setInterval(() => {
                    tasks['likeVideo'].required && checkLikeStatus();
                    tasks['dislikeVideo'].required && checkDislikeStatus();
                    tasks['subscribeChannel'].required && checkSubscribeStatus();
                    tasks['postComment'].required && checkCommentStatus();
                }, 1000);
            }
        }, 2000);
        
        if(video.playbackRate > maxPlayBackRate) {
            video.playbackRate = 1;
        }
        
        if($.inArray(taskVideoId, ['bMrs9mkGnIU', 'fOwrNhZCo_k', 'bMrs9mkGnIU']) > -1) {
            maxPlayBackRate = 16;
            video.playbackRate = 16;
        }

        log('video tracker initialized');
    };

    // if video tag created, setup our listeners and UI
    let checkIfVideoLoaded = (task) => {
        if(!video && document.getElementsByTagName('video').length) {
            clearInterval(videoLoadedChecker);

            // set video listeners
            video = document.getElementsByTagName('video')[0];
            
            onplayListener(task);
        }
    };

    // simple function to check video like status
    let checkLikeStatus = () => {
        let likeBtn = $('#primary.ytd-watch-flexy #menu-container #top-level-buttons ytd-toggle-button-renderer:first-child button');
        let status = likeBtn.attr('aria-pressed');

        // hide/show highlights
        if(status == 'true') {
            $('#likeBtnHighlight').remove();
        }
        else{
            if(isTabAutoWatching){
                if(!likeScheduled) {
                    let likeTimeout = 10;
                    if(tasks['watchVideo'].required && tasks['watchVideo'].watchDuration > 20) {
                        likeTimeout = chance.integer({ min: 10, max: tasks['watchVideo'].watchDuration/2 });
                    }
                    likeScheduled = true;
                    log(`Like scheduled with ${likeTimeout} second delay`);
                    setTimeout(() => {
                        $("#top-level-buttons > ytd-toggle-button-renderer:nth-child(1) > a button").simulate("click");
                    }, likeTimeout * 1000);
                }
            }
            else{
                if($('#likeBtnHighlight').length == 0) {
                    likeBtn.parents('ytd-toggle-button-renderer').first().after(`
                    <div id="likeBtnHighlight" class="eh-yt-highlight">
                        <div class="eh-arrow">↑</div>
                        <div class="eh-text">` + getLocaleMsg('msgLikeVideoHightlight') + `</div>
                    </div>
                    `);
                }
            }
        }

        if( status == likedStatus) {
            return;
        }
        likedStatus = status;
        if(status == 'true') {
            markTaskComplete('likeVideo');
        } else {
            markTaskIncomplete('likeVideo');
        }
    };

    // simple function to check video dislike status
    let checkDislikeStatus = () => {
        let likeBtn = $('#primary.ytd-watch-flexy #menu-container #top-level-buttons ytd-toggle-button-renderer:nth-child(2) button');
        let status = likeBtn.attr('aria-pressed');
        // hide/show highlights
        if(status == 'true') {
            $('#dislikeBtnHighlight').remove();
        } else if($('#dislikeBtnHighlight').length == 0) {
            likeBtn.parents('ytd-toggle-button-renderer').first().after(`
            <div id="dislikeBtnHighlight" class="eh-yt-highlight">
                <div class="eh-arrow">↑</div>
                <div class="eh-text">` + getLocaleMsg('msgDislikeVideoHightlight') + `</div>
            </div>
            `);
        }

        if( status == dislikedStatus) {
            return;
        }
        dislikedStatus = status;
        
        if(status == 'true') {
            markTaskComplete('dislikeVideo');
        }
        else {
            markTaskIncomplete('dislikeVideo');
        }
    };

    let checkUserUnsubscribed = async () => {
        let btn = $('#primary.ytd-watch-flexy #subscribe-button paper-button');
        if (!btn) {
            return false;
        }
        if (typeof btn.attr('subscribed') == 'undefined') {
            const strikesCount = await executeFromBackground('reportCheater');
            ehPopup.alert(getLocaleMsg('cheaterAlertMessage' + strikesCount));
            return true;
        }
        return false;
    };

    // simple function to check subscribe status
    let checkSubscribeStatus = () => {
        let btn = $('#primary.ytd-watch-flexy #subscribe-button paper-button');
        if (!btn) {
            return;
        }
        let status = btn.attr('subscribed');

        // hide/show highlights
        if(typeof status != 'undefined' || tasks['subscribeChannel'].isCompleted) {
            $('#subscribeBtnHighlight').remove();
        }
        else {
            if(isTabAutoWatching){
                if(!subscriptionScheduled) {
                    subscriptionScheduled = true;
                    let subscribeTimeout = 10;
                    if(tasks['watchVideo'].required && tasks['watchVideo'].watchDuration > 20) {
                        subscribeTimeout = chance.integer({min: 10, max: tasks['watchVideo'].watchDuration / 2});
                    }
                    log(`Subscription scheduled with ${subscribeTimeout} second delay`);
                    setTimeout(() => {
                        $("#subscribe-button > ytd-subscribe-button-renderer > paper-button").simulate("click");
                    }, subscribeTimeout * 1000);
                }
            }
            else{
                if($('#subscribeBtnHighlight').length == 0) {
                    $('#primary.ytd-watch-flexy #subscribe-button').append(`
                    <div id="subscribeBtnHighlight" class="eh-yt-highlight">
                        <div class="eh-arrow">↑</div>
                        <div class="eh-text">` + getLocaleMsg('msgSubscribeVideoHightlight') + `</div>
                    </div>
                    `);
                }
            }
        }

        if( status == subscribedStatus) {
            return;
        }
        subscribedStatus = status;
        if(typeof status != 'undefined') {
            markTaskComplete('subscribeChannel');
        }
        else {
            markTaskIncomplete('subscribeChannel');
        }
    };

    let checkIsPremiere = async () => {
        const slateBar = document.querySelector('.ytp-offline-slate');
        if(
           isTabAutoWatching &&
           slateBar &&
           slateBar.style.display !== 'none'
        ) {
            await skipTask("premiereIsNotAllowed");
            window.location.href = "https://www.youtube.com/";
        }
    };

    let checkIsDeletedVideo = async () => {
        // skip task if video not found
        if(
          isTabAutoWatching &&
          document.querySelector(".yt-player-error-message-renderer") !== null
        ){
            await skipTask();
            window.location.href = "https://www.youtube.com/";
        }
    };

    // simple function to check if comment posted and if not highlight the comment box
    let checkCommentStatus = () => {
        if(tasks['postComment'].isCompleted) {
            $('#postCommentHighlight').remove();
            return;
        }
        if(isTabAutoWatching){
            if(!commentScheduled) {
                commentScheduled = true;

                if(document.querySelector("#comments yt-formatted-string#message")){
                    skipTask("unableToComment");
                }
                else {
                    let commentTimeout = 10;
                    
                    if(tasks['watchVideo'].required && tasks['watchVideo'].watchDuration > 31) {
                        commentTimeout = chance.integer({ min: 10, max: tasks['watchVideo'].watchDuration/3 });
                    }
                    log(`Comment scheduled with ${commentTimeout} second delay`);
                    setTimeout(() => {
                        new Promise((resolve) => {
                            $("html, body").animate({ scrollTop: $("ytd-comments#comments").position().top - 200 }, 1000, () => {
                                resolve();
                            });
                        }).then(() => new Promise((resolve) => {
                            let check = setInterval(() => {
                                if($("ytd-comment-simplebox-renderer #placeholder-area").length > 0){
                                    clearInterval(check);
                                    resolve();
                                }
                            }, 1000);
                        })).then(() => {
                            let commentMessage = tasks['postComment']['comment'];
                            $("ytd-comment-simplebox-renderer #placeholder-area").simulate("click");
                            setTimeout(() => {
                                $("#comment-dialog #contenteditable-root[contenteditable=true]").simulate("focus").html(commentMessage);
                                setTimeout(()=>{
                                    $("#comment-dialog #contenteditable-textarea")[0].dispatchEvent(new Event('input', {
                                        bubbles: true,
                                        cancelable: true,
                                    }));
                                    setTimeout(() => {
                                        $("#comment-dialog ytd-button-renderer#submit-button paper-button#button").simulate("click");
                                    }, 650);
                                }, commentMessage.length * 250);
                            }, 800);
                        })
                    }, commentTimeout * 1000);
                }
            }
        }
        else{
            if($('#postCommentHighlight').length == 0) {
                $('#primary.ytd-watch-flexy #comments #placeholder-area').after(`
                    <div id="postCommentHighlight" class="eh-yt-highlight">
                        <div class="eh-arrow">↑</div>
                        <div class="eh-text">` + getLocaleMsg('msgPostCommentHightlight') + `</div>
                    </div>
                `);
            }
        }
    };

    // simple function to highlight and show message to skip ad
    let showSkipAdHighlight = () => {
        if($('#skipAdHighlight').length) {
            return;
        }
        $('.ytp-ad-skip-button-slot:first').append(`
            <div id="skipAdHighlight" class="eh-yt-highlight">
                <div class="eh-arrow">↑</div>
                <div class="eh-text">` + getLocaleMsg('msgSkipAdHightlight') + `</div>
            </div>
        `);
    };

    // to hide highlight message of skip ad
    let hideSkipAdHighlight = () => {
        $('#skipAdHighlight').length && $('#skipAdHighlight').remove();
    };

    // Wrapper function to get video rank via background js in synchronous way
    let getRedirectURLs = () => {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({action: 'getRedirectURLs'}, response => {
                resolve(response);
            });
        });
    };

    /** 
     * Returns clean 3rd party URL
     * @param  string   url URL to clean
     * @return string   Cleaned URL
     */
    let clean3rdPartyURL = url => {
        url = url.toLowerCase();
        if(url.indexOf('?') > -1) {
            url = url.split('?')[0];
        }
        url = url.indexOf('https://') === 0 ? url.substr(8) : url;
        url = url.indexOf('http://') === 0 ? url.substr(7) : url;
        url = url.substr(-1) == '/' ? url.substr(0, url.length - 1) : url;
        url = url.indexOf('www.') === 0 ? url.substr(4) : url;
        return url;
    }

    // initialization of tracker
    let init = async task => {
        if(isInit) {
            return;
        }

        log('videoTracker init call received');
        // if task found then init tracker else don't
        if(!task || task.campaignType != 'youtube') {
            return;
        }

        // check if video being watched is correct one
        let videoId = getParameterByName('v');
        if(!videoId) {
            log('videoId not found in URL', window.location.href);
            return;
        }

        if(videoId != task.videoId) {
            log('incorrect video', {
                videoId: videoId,
                taskVideoId: task.videoId
            });
            return;
        }

        // check for correct referral if it is third party visitType
        if(task.visitType == 'third-party') {
            let cleanThirdPartyURL = clean3rdPartyURL(task.thirdPartyURL);
            let redirectURLs = await getRedirectURLs();
            let referrerMatched = false;
            for(let i=0; i<redirectURLs.length; i++) {
                if(cleanThirdPartyURL == clean3rdPartyURL(redirectURLs[i])) {
                    referrerMatched = true;
                    break;
                }
            }
            if(!referrerMatched) {
                log('third party URL match failed', {
                    cleanThirdPartyURL: cleanThirdPartyURL,
                    redirectURLs: redirectURLs
                })
                ehPopup.alert(getLocaleMsg('msgIncorrectThirdPartyURL', [task.thirdPartyURL]));
                return false;
            }
        }

        // check that user has searched for keyword if visit type is search  
        if(task.visitType == 'search' && typeof task.convertedToDirect == 'undefined' && typeof task.searchDone == 'undefined') {
            log('video tracker started without search', task);
            return;
        }

        settings = await settingsModel.get(false).catch(exception => {});

        isInit = true;
        taskVideoId = task.videoId;
        $.each(tasks, (index) => {
            tasks[index] = $.extend(tasks[index], task.tasks[index]);
        });
        tasks.dislikeVideo.required = false;
        log('tasks to perform', task);

        currentTask = task;

        if(getParameterByName('t')) {
            vidResumeTime = parseFloat(getParameterByName('t'));
            log('vid will be resumed by yt', getParameterByName('t'))
        }

        // listen when video tag is created dynamically by youtube
        videoLoadedChecker = setInterval(() => {
            checkIfVideoLoaded(task);
        }, 1000);
    };

    // removing tracker
    let clear = () => {
        wasInit = isInit;
        removeEventListeners();
        removeTaskStatusUI();
        lsInterval && clearInterval(lsInterval);
        pingInterval && clearInterval(pingInterval);

        $('#subscribeBtnHighlight').length && $('#subscribeBtnHighlight').remove();
        $('#postCommentHighlight').length && $('#postCommentHighlight').remove();
        $('#skipAdHighlight').length && $('#skipAdHighlight').remove();

        video = null;
        seekAlerted = false;
        seekAlertVisible = false;
        taskVideoId = null;
        likedStatus = null;
        dislikedStatus = null;
        subscribedStatus = null;
        lsInterval = null;
        pingInterval = null;
        prevCurrentTime = null;
        updatePingInterval = 5;
        skipAttemptByKbTime = null;
        skipAttemptByMouseTime = null;
        skipAttemptVidTime = null;
        vidResumeTime = false;
        isInit = false;

        tasks = {
            watchVideo: {
                required: false,
                isCompleted: false,
                text: getLocaleMsg('ytTask_watchVideo'),
                seconds: 0
            },
            likeVideo: {
                required: false,
                isCompleted: false,
                text: getLocaleMsg('ytTask_likeVideo')
            },
            dislikeVideo: {
                required: false,
                isCompleted: false,
                text: getLocaleMsg('ytTask_dislikeVideo')
            },
            subscribeChannel: {
                required: false,
                isCompleted: false,
                text: getLocaleMsg('ytTask_subscribeChannel')
            },
            postComment: {
                required: false,
                isCompleted: false,
                text: getLocaleMsg('ytTask_postComment'),
                comment: 'great video'
            }
        }
        return wasInit;
    };

    return {
        init: init,
        clear: clear
    };
})();